package com.example.kiddoji

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class StoryActivity : AppCompatActivity() {   // ✅ extends AppCompatActivity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.story)  // ✅ correct layout
    }
}