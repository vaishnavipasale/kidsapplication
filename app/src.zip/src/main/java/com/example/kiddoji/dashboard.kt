package com.example.kiddoji
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.kiddoji.PoemBookActivity
class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        findViewById<Button>(R.id.button1).setOnClickListener {
            startActivity(Intent(this, Alphabets::class.java))
        }

        findViewById<Button>(R.id.button2).setOnClickListener {
            startActivity(Intent(this, DaysActivity::class.java))
        }

        findViewById<Button>(R.id.button3).setOnClickListener {
            startActivity(Intent(this, MonthsofyearsActivity::class.java))
        }

        findViewById<Button>(R.id.button4).setOnClickListener {
            startActivity(Intent(this, AnimalActivity::class.java))
        }

        findViewById<Button>(R.id.button5).setOnClickListener {
            startActivity(Intent(this, FruitsActivity::class.java))
        }

        findViewById<Button>(R.id.button6).setOnClickListener {
            startActivity(Intent(this, BirdsActivity::class.java))
        }

        findViewById<Button>(R.id.button7).setOnClickListener {
            startActivity(Intent(this, VegetablesActivity::class.java))
        }

        findViewById<Button>(R.id.button8).setOnClickListener {
            startActivity(Intent(this, com.example.kiddoji.PoemBookActivity::class.java))

        }

        findViewById<Button>(R.id.button9).setOnClickListener {
            startActivity(Intent(this, StoryActivity::class.java))
        }


    }
}